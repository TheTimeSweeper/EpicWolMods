# Time Wizard
Keys configurable
- Press `I` to speed up time
- Press `K` to slow down time
- Press `O` to reset Time to 1
- Press `L` to pause time completely (set to 0)
- Press `;` to enable/disable these hotkeys so you don't accidentally press them

Any questions or feedback or mind exploding issues, ping/message `thetimesweeper` on Discord
___

### Installation (manual):
- Make sure you have the dependencies installed.
- Download and extract the zip.
- Place the .dll file into your BepInEx `plugins` folder

### Changelog:

`0.1.0`
 - c: