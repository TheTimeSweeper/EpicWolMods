# Silly Arcana
### Gust Burst
Re-added, my beloved  
![mybeloved](https://raw.githubusercontent.com/TheTimeSweeper/EpicWolMods/master/SillySkills/Release/readme/AirChannelDashGood.gif)

### Gale Burst
A brand new standard arcana, inspired by Gust Burst  
![mybeloved2](https://raw.githubusercontent.com/TheTimeSweeper/EpicWolMods/master/SillySkills/Release/readme/GustBurstButBig.gif)

Any questions or feedback or mind exploding issues, ping/message `thetimesweeper` on Discord

### Credits
- `only_going_up_fr0m_here` - development on modded arcana, icon loading code
- `aries13` - Gale Burst icon

### Plans (that may or may not happen)
- Phantom Blob
- More Gust Burst spells. Gust Burst for all elements!

___
### Installation:
- Make sure all dependencies are installed
- Download and extract the .zip
- in your `BepInEx/plugins` folder create a new folder called `TheTimesweeper-SillySkills`
- drag the contents of this mod's `plugins` folder into this new folder.

### Changelog:

`0.1.0`
 - c: