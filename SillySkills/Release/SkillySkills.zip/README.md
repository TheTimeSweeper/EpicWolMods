# Silly Arcana
### Gust Burst ![icon](https://raw.githubusercontent.com/TheTimeSweeper/EpicWolMods/master/_EpicUnityProject/Assets/Mods/SkillsUnfunnyBundle/AirChannelDashGood.png)
Re-added, my beloved  
![mybeloved](https://raw.githubusercontent.com/TheTimeSweeper/EpicWolMods/master/SillySkills/Release/readme/AirChannelDashGood.gif)

### Gale Burst ![icon](https://raw.githubusercontent.com/TheTimeSweeper/EpicWolMods/master/_EpicUnityProject/Assets/Mods/SkillsUnfunnyBundle/GustBurstButBig.png)
A brand new standard arcana, inspired by Gust Burst  
![mybeloved2](https://raw.githubusercontent.com/TheTimeSweeper/EpicWolMods/master/SillySkills/Release/readme/GustBurstButBig.gif)

### Stone Outburst ![icon](https://raw.githubusercontent.com/TheTimeSweeper/EpicWolMods/master/_EpicUnityProject/Assets/Mods/SkillsUnfunnyBundle/GustBurstButEarth.png)
I'm not stuck in here with you, you're stuck in here with me  
![mybeloved3](https://raw.githubusercontent.com/TheTimeSweeper/EpicWolMods/master/SillySkills/Release/readme/GustBurstButEarth.gif)

Any questions or feedback or mind exploding issues, ping/message `thetimesweeper` on Discord

### Credits
- `aries13` - King of icons and custom visuals
- `only_going_up_fr0m_here` - development on modded arcana

### Plans (that may or may not happen)
- Phantom Blob
- More Gust Burst spells. Gust Burst for all elements!
___
### Installation:
- Make sure all dependencies are installed
- Download and extract the .zip
- in your `BepInEx/plugins` folder create a new folder called `TheTimesweeper-SillySkills`
- drag the contents of this mod's `plugins` folder into this new folder.

### Changelog:
`1.1.2`
- fixed the previous fix messing with knockbacks when enhanced
- last hotfix I hope

`1.1.1`
- fixed Stone Outburst dealing extra overlapping damage

`1.1.0`
 - added new arcana Stone Outburst (name pending)
   - I think the first arcana with custom visuals?
 - fixed prices on arcana
 - retconned version numbers

`1.0.0`
 - c: