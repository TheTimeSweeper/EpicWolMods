# SelfBreakingProjectilesFix

Any questions or feedback or mind exploding issues, ping/message `thetimesweeper` on Discord
___

### Installation (manual):
- Make sure you have the dependencies installed.
- Download and extract the zip.
- Place the .dll file into your BepInEx `plugins` folder

### Changelog:

`1.0.0`
 - c: