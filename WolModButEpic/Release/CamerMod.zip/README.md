# Camera Mod
### Co-op
- Allows players to run away from each other, zooming out the camera as it does in PVP

### Co-op and PVP
- Improves camera zooming to keep both players on screen

Before vs After:

<img width="420" src="https://raw.githubusercontent.com/TheTimeSweeper/EpicWolMods/master/WolModButEpic/Release/readme/befor.png" />
<img width="420" src="https://raw.githubusercontent.com/TheTimeSweeper/EpicWolMods/master/WolModButEpic/Release/readme/aftor.png" />

### Co-op, PVP, and Solo
- By default, zooms the camera out a tad (configurable).
- Press F1 and F2 to zoom in and out the camera at will.
- Press F3 to reset the camera back to vanilla default.

Any questions or feedback or mind exploding issues, ping/message `thetimesweeper` on Discord
___

### Installation:
- Make sure you have the dependencies installed.
- Download and extract the zip.
- Place the .dll file into your BepInEx `plugins` folder

### Changelog:

`1.0.0`
 - c: