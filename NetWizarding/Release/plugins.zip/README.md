# Yes, really
Very barebones online multiplayer setup that fakes it heavily, but might just be decent enough.
- Only works for PVP
- Currently always expecting multiplayer. Uninstall mod to go back to normal
- tons of interactions untested  
___

### Installation (manual):
- Make sure you have the dependencies installed.
- Download and extract the zip.
- Place the .dll file into your BepInEx `plugins` folder

### Changelog:

`0.1.0`
 - c: