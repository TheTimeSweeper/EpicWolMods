# GoldCounter
Shows a little counter next to your gold and gems that accumulates as you pick up gold, letting you really see how much you gained from an enemy or chest or whatever.

Any questions or feedback or mind exploding issues, ping/message `thetimesweeper` on Discord
___

### Installation (manual):
- Make sure you have the dependencies installed.
- Download and extract the zip.
- Place the .dll file into your BepInEx `plugins` folder

### Changelog:

`0.1.0`
 - c: