# Plat Wallet Upgrade
- Allows you to hold more than 999 max gems
- By default, "current chaos gems held" relics will still only consider you having maximum of 999
  - But you can increase this cap in config

Any questions or feedback or mind exploding issues, ping/message `thetimesweeper` on Discord
### Changelog:

`1.0.0`
 - c: