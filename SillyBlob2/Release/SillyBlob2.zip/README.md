# Menacing Blob

![rol](https://raw.githubusercontent.com/TheTimeSweeper/EpicWolMods/master/SillyBlob2/Release/readme/blobrollvid_4.gif)

Any questions or feedback or mind exploding issues, ping/message `sweepersecret` on Discord
### Changelog:

`0.1.0`
 - c: