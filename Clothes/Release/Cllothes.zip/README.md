# Clothes
Adds some robes. Custom colors are disabled if TournamentEdition is installed due to conflicts. hopefully fixed soon.

![cool robes](https://raw.githubusercontent.com/TheTimeSweeper/EpicWolMods/master/Clothes/Release/readme/Clothes.png)

Any questions or feedback or mind exploding issues, ping/message `thetimesweeper` on Discord.  
I would especially like feedback on Impatience, feeling-wise and balance-wise.

### Plans
- Pandemonium cloak from shovel knight
- Config custom cloak
___

### Installation (manual):
- Make sure all dependencies are installed
- Download and extract the .zip
- in your `BepInEx/plugins` folder create a new folder called `TheTimesweeper-Clothes`
- drag the contents of this mod's `plugins` folder into this new folder.

### Changelog:

`0.5.0`
 - c: