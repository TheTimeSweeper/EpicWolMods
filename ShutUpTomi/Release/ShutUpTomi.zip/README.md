# DID YOU KNOW THAT YOU CAN QUICK SWAP YOUR ARCANA INTO YOUR HAND?
# PRESS AND HOLD THE MENU BUTTON, THEN PRESS THE ARCANA BUTTON YOU WANT TO SWAP TO OR VICE VERSA!
# REMEMBER, YOU CAN ONLY SWAP OUT STANDARD ARCANA!

Any questions or feedback or mind exploding issues, ping/message `thetimesweeper` on Discord
___

### Installation (manual):
- Make sure you have the dependencies installed.
- Download and extract the zip.
- Place the .dll file into your BepInEx `plugins` folder

### Changelog:

`0.1.0`
 - c: