﻿namespace Rewired.Integration.RexEngine.Editor {
    using UnityEngine;
    using UnityEditor;

    public static class MenuItems {

        private const string assetGuid_rewiredInputManager_1Player = "d104e5a895ccaa041ba37f01fcf5ba22";
        private const string assetGuid_rewiredInputManager_2Player = "c563d66a4fb861341b876633bca2dae0";

        [MenuItem(Rewired.Consts.menuRoot + "/Integration/Rex Engine/Create/Rewired Input Manager (1-player)")]
        [MenuItem("GameObject/Create Other/Rewired/Integration/Rex Engine/Rewired Input Manager (1-player)")]
        public static void CreateInputManager1Player() {
            if(!InstantiatePrefabAtGuid(assetGuid_rewiredInputManager_1Player, "Rewired Rex Engine Input Manager", true)) {
                Debug.LogError("Unable to locate prefab file. Please reinstall the Rex Engine integration pack.");
            }
        }

        [MenuItem(Rewired.Consts.menuRoot + "/Integration/Rex Engine/Create/Rewired Input Manager (2-player)")]
        [MenuItem("GameObject/Create Other/Rewired/Integration/Rex Engine/Rewired Input Manager (2-player)")]
        public static void CreateInputManager2Player() {
            if (!InstantiatePrefabAtGuid(assetGuid_rewiredInputManager_2Player, "Rewired Rex Engine Input Manager", true)) {
                Debug.LogError("Unable to locate prefab file. Please reinstall the Rex Engine integration pack.");
            }
        }

        private static bool InstantiatePrefabAtGuid(string guid, string name, bool breakPrefabInstance) {
            GameObject prefab = LoadAssetAtGuid<GameObject>(guid);
            if(prefab == null) return false;

            GameObject instance = GameObject.Instantiate(prefab);
            if(instance == null) return false;

            if(!string.IsNullOrEmpty(name)) {
                instance.name = name;
            } else {
                // Strip (Clone) off the end of the name
                if(instance.name.EndsWith("(Clone)")) {
                    instance.name = instance.name.Substring(0, instance.name.Length - 7);
                }
            }

#if !UNITY_2018_3_OR_NEWER
            if(breakPrefabInstance) PrefabUtility.DisconnectPrefabInstance(instance);
#endif

            Undo.RegisterCreatedObjectUndo(instance, "Create " + prefab.name);
            return true;
        }

        private static T LoadAssetAtGuid<T>(string guid) where T : Object {
            return AssetDatabase.LoadAssetAtPath<T>(AssetDatabase.GUIDToAssetPath(guid));
        }
    }
}